---
name: Help
about: I have a question
title: ''
labels: question
assignees: ''

---

<!--- 
Please make sure you've:
 - read the FAQ https://github.com/plamere/spotipy/blob/master/FAQ.md
 - read the documentation https://spotipy.readthedocs.io/en/latest/
 - searched older issues

If your question is about code, please share the code you are using
--->
